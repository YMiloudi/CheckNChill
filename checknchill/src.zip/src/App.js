import React from 'react';
import CitySearch from './components/search/CitySearch';
import Weather from './components/weather/Weather';



class App extends React.Component {
  render(){
    return (
      <div className="App">
        <CitySearch/>
        <Weather/>
      </div>

    );
  }
}



export default App;